import numpy as np

class AlmgrenChrissModel:
    def __init__(self, eta=0.142, gamma=0.35):
        self.eta = eta  # temporary impact coefficient
        self.gamma = gamma  # permanent impact coefficient

    def estimate_impact(self, order_size, volatility, liquidity):
        """
        Basic Almgren-Chriss market impact model.
        """
        temp_impact = self.eta * (order_size / liquidity)
        perm_impact = self.gamma * volatility * (order_size / liquidity)
        return temp_impact + perm_impact
