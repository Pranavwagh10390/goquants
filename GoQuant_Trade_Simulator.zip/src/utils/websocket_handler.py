import asyncio
import websockets
import json
import time
import logging

class OrderBookClient:
    def __init__(self, url, symbol, on_update_callback):
        self.url = url
        self.symbol = symbol
        self.ws = None
        self.on_update_callback = on_update_callback

    async def connect(self):
        async with websockets.connect(self.url) as websocket:
            self.ws = websocket
            await self.subscribe()
            await self.receive_data()

    async def subscribe(self):
        logging.info(f"Subscribed to {self.symbol}")

    async def receive_data(self):
        try:
            async for message in self.ws:
                tick_start_time = time.time()
                data = json.loads(message)
                self.on_update_callback(data, tick_start_time)
        except Exception as e:
            logging.error(f"Error receiving data: {e}")

    def run(self):
        asyncio.run(self.connect())
