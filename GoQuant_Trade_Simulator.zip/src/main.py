from src.utils.websocket_handler import OrderBookClient

def on_orderbook_update(data, tick_start_time):
    print("Orderbook Tick:", data)
    # TODO: Process L2 orderbook, compute models, update GUI

if __name__ == "__main__":
    url = "wss://ws.gomarket-cpp.goquant.io/ws/l2-orderbook/okx/BTC-USDT-SWAP"
    symbol = "BTC-USDT-SWAP"
    client = OrderBookClient(url, symbol, on_orderbook_update)
    client.run()
