# GUI implementation with PyQt5
