# GoQuant Trade Simulator

Assignment solution for GoQuant recruitment process.
