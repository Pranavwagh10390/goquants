# Documentation for GoQuant Trade Simulator
